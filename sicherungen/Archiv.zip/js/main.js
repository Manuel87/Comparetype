/*Globale Variablen*/
/*------------------------------------------------------------------------*/
/*------------------------------------------------------------------------*/
var debugging = true;


var ppi, ppcm;

var quickdebug = "";

var diagonale_cm = false;
var diagonale_inch = false;
var long_cm = false,
    long_inch = false;


reading_distance_cm = 80; //cm

//Mein Mac
diagonale_inch = 13.3;
diagonale_cm = 33.7;
long_cm = 28.65;


//Groß er Bildschirm
diagonale_inch = 22;
diagonale_cm = 55.8;
long_cm = 47.35;

// check if the window is on another monitor: http://stackoverflow.com/questions/16363474/window-open-on-a-multi-monitor-dual-monitor-system-where-does-window-pop-up






UnitSystem = "metric";


function myRound(number, digits) {
    precission = Math.pow(10, digits);
    return Math.round(number * precission) / precission;

}

// CONVERSION MATH
function px2pt(px, ppi) {
    pt = 0;
    return pt;
}



function getppi(px, inch) {
    pt = px / inch;
    return pt;
}

function getppcm(px, ppi) {
    pt = 0;
    return pt;
}



var myMeasurements = {
    window_width: document.documentElement.clientWidth, // (same but faster)  $('body').innerWidth(); //
    window_height: document.documentElement.clientHeight, //$(window).height(); //
    screen_width: window.screen.width, //window.screen.availWidth,
    screen_height: window.screen.height, // window.screen.availHeight,
    screen_diagonal: 0
};

// FOR IPHONE, … …
if (myMeasurements.screen_width === undefined) myMeasurements.screen_width = window.innerWidth;
if (myMeasurements.screen_width === undefined) myMeasurements.screen_height = window.innerHeight;


myMeasurements.screen_diagonal = Math.sqrt(Math.pow(myMeasurements.screen_width, 2) + Math.pow(myMeasurements.screen_height, 2));




var convertUnits = {
    px2pt: 1.5,
    px2inch: 1,
    px2mm: 1,
    px2cm: 1,
    pt2px: 1,
    mm2px: 1,

    in2pt: 72,
    pt2in: 1 / 72,
    in2cm: 2.54,
    cm2in: 1 / 2.54,

    mm2pt: 1,
    pt2mm: 1,
    pt2vu: 1,
    mm2vu: 1,
    vucm2pt: 0.00824565,
    vucm2cm: 0.0002908882,
    vucm2mm: 0.002908882
};

// Großer Bildschirm


//input
function setPpiByDiagonal(inch) {
    ppi = myRound((myMeasurements.screen_diagonal / inch), 3);
}

function setPpiByLongSide(inch) {

    if (myMeasurements.screen_width > myMeasurements.screen_height) {
        ppi = myRound((myMeasurements.screen_width / inch), 3); //Math.round((myMeasurements.screen_width / inch) * 100) / 100;
    } else {
        ppi = myRound((myMeasurements.screen_height / inch), 3);
    }
}

function setPpcmByDiagonal(cm) {
    ppcm = myRound((myMeasurements.screen_diagonal / cm), 3);
}

function setPpcmByLongSide(cm) {

    if (myMeasurements.screen_width > myMeasurements.screen_height) {
        ppcm = myRound((myMeasurements.screen_width / cm), 3); //Math.round((myMeasurements.screen_width / inch) * 100) / 100;
    } else {
        ppcm = myRound((myMeasurements.screen_height / cm), 3);
    }
}



switch (UnitSystem) {
    case "metric":
        if (diagonale_cm) {
            setPpcmByDiagonal(diagonale_cm);
            setPpiByDiagonal(diagonale_cm * convertUnits.cm2in);
        } else if (long_cm) {
            setPpcmByLongSide(long_cm);
            setPpiByLongSide(long_cm * convertUnits.cm2in);
        } else {
            setPpiByDiagonal(diagonale_inch);
            setPpcmByDiagonal(diagonale_inch * convertUnits.in2cm);
            //setPpcmByA4();
        }

        break;
    case "mix":
        if (diagonale_inch) {
            setPpiByDiagonal(diagonale_inch);
            setPpcmByDiagonal(diagonale_inch * convertUnits.in2cm);
        } else {
            setPpcmByLongSide(long_cm);
            setPpiByLongSide(long_cm * convertUnits.cm2in);
        }

        break;
    case "non-metric":
        if (diagonale_inch) {
            setPpiByDiagonal(diagonale_inch);
            setPpcmByDiagonal(diagonale_inch * convertUnits.in2cm);
        } else {
            setPpiByLongSide(long_inch);
            setPpcmByLongSide(long_inch * convertUnits.in2cm);
        }
        break;
}

convertUnits.px2pt = myRound(1 / ppi * convertUnits.in2pt, 3);
convertUnits.pt2px = myRound(1 / convertUnits.px2pt, 3);
convertUnits.px2mm = myRound(1 / ppcm * 10, 3);
convertUnits.mm2px = myRound(1 / convertUnits.px2mm, 3);
convertUnits.vu2pt = myRound(convertUnits.vucm2pt * reading_distance_cm, 6);
convertUnits.vu2px = myRound(convertUnits.vucm2pt * reading_distance_cm * convertUnits.pt2px, 6);
quickdebug += "1vu = " + convertUnits.vu2pt + "pt <br/>";
quickdebug += "1vu = " + convertUnits.vu2px + "px <br/>";

quickdebug += myMeasurements.screen_width + " x " + myMeasurements.screen_height + "" + "<br/>";
quickdebug += ppi + " ppi <br/>";
quickdebug += ppcm + " ppcm <br/>";
quickdebug += "1pt = " + convertUnits.pt2px + "px <br/>";
quickdebug += "1px = " + convertUnits.px2pt + "pt <br/>";
// quickdebug += "1pt = " + convertUnits.pt2px + "px <br/>";
// quickdebug += "1mm = " + convertUnits.mm2px + "px <br/>";

//quickdebug += "<br/>" + 200 * convertUnits.px2mm; // Rundungsfehler!! Aber Warum??

/*Funktionen*/
/*------------------------------------------------------------------------*/
/*------------------------------------------------------------------------*/


mypt = convertUnits.pt2px;
mymm = convertUnits.mm2px;
myvu = convertUnits.vu2px;


myReadingSize = 13 * 0.9 * myvu; // SMallest: "7-8px" / "7su"  // 5px/5su) //3 * mypt //"5.5px" // smallest -> 7px (~6.5-7)


quickdebug += "mypt = " + mypt + " <br/>";
//// D o c u m e n t – R e a d y
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
$(document).ready(function() {
    $(".detail").css({
        "font-size": "100px" //8 * mypt
    });

    $(".readingsize .large").css({
        "font-size": 6 * mypt
    });
    $(".readingsize").css({
        "font-size": myReadingSize //
    });
    $(".readingsize .small").css({
        "font-size": 3 * mypt
    });




    initial_window_height = $(window).height();
    // S I Z E S
    /////
    ppi = 96;
    //myMeasurements.screen_width;



    // Real Typographic Font Size


    typographicSize_em = 1.0;

    // Get all Fontsizes
    detailfontsize = parseInt($(".detail").css("font-size"), 10);

    //
    height_1 = $(".font1 .square").height() / detailfontsize; // below 8px x-height its getting werid -> (5px ex -> 7,5(15px) best to measure, not bigger!)
    height_2 = $(".font2 .square").height() / detailfontsize;


    new_x_height = detailfontsize * typographicSize_em;
    fontsizeadjust_1 = typographicSize_em / height_1;
    fontsizeadjust_2 = typographicSize_em / height_2;

    quickdebug += "font1 x" + fontsizeadjust_1 + "% <br/>";
    quickdebug += "font2 x" + fontsizeadjust_2 + "% <br/>";

    $("#report").html("xH_1 = " + height_1 + " | xH_2 = " + height_2 + "<br/><br/><br/>Normalize… xH => " + typographicSize_em);

    $(".font2").css({
        "font-size": fontsizeadjust_2 * 100 + "%",

    });
    $(".font1").css({
        "font-size": fontsizeadjust_1 * 100 + "%"
    });


    letters = '<span class="char">' + $(".text").html().split("").join('</span><span class="char">') + "</span>";
    words = letters.split('<span class="char"> </span>').join('</span> <span class="words">');

    $(".text").html('<span class="words">' + words + '</span>');

    $('.readingsize .words').prepend('<span class="mybefore "></span>'); //after
    $('.readingsize .words').prepend('<span class="mybefore2 "></span>'); //after
    $('.readingsize .words').append('<span class="myafter "></span>'); //after

    $(".readingsize .words .mybefore").css({
        "height": myReadingSize //        SMallest: "7-8px" / "7su"  // 5px/5su) //3 * mypt //"5.5px" // smallest -> 7px (~6.5-7)
    });

    $(".readingsize .words .mybefore2").css({
        "height": myReadingSize * 2
    });


    /// Show Measurements

    $(".detail").append('<div class="measurement">' + detailfontsize * convertUnits.px2pt + " " + detailfontsize + 'px</div>');
    // ( Divide by 2 as a fallback for browsers wich don’t read the 'ex' out of a font ) )




    // DEBUGG
    if (debugging) {
        $('.debugging').append('<span>' + quickdebug +

            '</div>');

    }
});


//-----------------------------------------------------
// E N D  —  Document on ready




/// W i n d o w - R e s i z e
//--------------------------------------------

resizeTimer = 0;

$(window).resize(function() {

    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function() {

        container_width = $("#container").width();
        window_height = $(window).height();

        //MyResize(container_width, window_height)},500);
    });
});
// E N D - Window Resize


/*
function getBrowserWith() {
    if (($.browser.msie == true && $.browser.version == '9.0') || $.browser.webkit == true || $.browser.mozilla == true)
        return window.innerWidth;
    else if (($.browser.msie == true) && ($.browser.version == '7.0' || $.browser.version == '8.0'))
        return document.documentElement.clientWidth;
    else
        return screen.width;
}*/
